export enum SignInResponse {
    BadCreds = 0,
    BadUser = 1,
    Ok = 2
}
